import React, { Component } from "react";

export default class OrderTracking extends Component {
  render() {
    return <div>Order Tracking</div>;
  }
}
